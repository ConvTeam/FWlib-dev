#include <stdlib.h>
#include <stdio.h>

#include <pcap.h>


int main(int argc, char **argv)
{
	pcap_if_t *alldevs;
	pcap_if_t *d;
	pcap_t *fp;
	char errbuf[PCAP_ERRBUF_SIZE];
	u_char packet[256];
	u_char dst_addr[6] = {0x00, 0x08, 0xDC, 0x11, 0x22, 0x33};
	int i=0;
	int inum;
	char cont=0;
	
	/* Retrieve the device list */
	if(pcap_findalldevs(&alldevs, errbuf) == -1)
	{
		fprintf(stderr,"Error in pcap_findalldevs: %s\n", errbuf);
		exit(1);
	}
	
	/* Print the list */
	for(d=alldevs; d; d=d->next)
	{
		printf("%d. %s", ++i, d->name);
		if (d->description)
			printf(" (%s)\n", d->description);
		else
			printf(" (No description available)\n");
	}
	
	if(i==0)
	{
		printf("\nNo interfaces found! Make sure WinPcap is installed.\n");
		return -1;
	}
	
	printf("Enter the interface number (1-%d):",i);
	scanf_s("%d", &inum);
	getchar();
	
	if(inum < 1 || inum > i)
	{
		printf("\nInterface number out of range.\n");
		/* Free the device list */
		pcap_freealldevs(alldevs);
		return -1;
	}
	
	/* Jump to the selected adapter */
	for(d=alldevs, i=0; i< inum-1 ;d=d->next, i++);
	
	/* Open the adapter */
	if ((fp = pcap_open_live(d->name,		// name of the device
							 65536,			// portion of the packet to capture. It doesn't matter in this case 
							 1,				// promiscuous mode (nonzero means promiscuous)
							 1000,			// read timeout
							 errbuf			// error buffer
							 )) == NULL)
	{
		fprintf(stderr,"\nUnable to open the adapter. %s is not supported by WinPcap\n", argv[1]);
		/* Free the device list */
		pcap_freealldevs(alldevs);
		return 2;
	}

	/* Supposing to be on ethernet, set mac destination to FF:FF:FF:FF:FF:FF */
	packet[0]=0xFF;
	packet[1]=0xFF;
	packet[2]=0xFF;
	packet[3]=0xFF;
	packet[4]=0xFF;
	packet[5]=0xFF;
	
	/* Fill the rest of the packet */
	for(i=0;i<(6*16);i++)
	{
		packet[i+6]= dst_addr[i%6];
	}

	while(cont != 'N'){
		/* Send down the packet */
		if (pcap_sendpacket(fp,	// Adapter
			packet,				// buffer with the packet
			(6*16+6)			// size
			) != 0)
		{
			fprintf(stderr,"\nError sending the packet: %s\n", pcap_geterr(fp));
			/* Free the device list */
			pcap_freealldevs(alldevs);
			return 3;
		}
		printf("Resend?\n(Yes: 'Enter key', No: 'N')\n");
		scanf_s("%c",&cont, 1);
	}

	/* Free the device list */
	pcap_freealldevs(alldevs);
	pcap_close(fp);	
	return 0;
}

